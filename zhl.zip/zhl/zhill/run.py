import scrapy.cmdline
scrapy.cmdline.execute(['scrapy','crawl','zhilian1'])