import os
# os.system('start '+r'D:\AI161\第三阶段\代码\Python161爬虫\com\baizhi\Python161\scrapy框架\job\day1_urllib模块.md')
# os.system('scrapy crawl '+'job51')


import scrapy.cmdline
scrapy.cmdline.execute(['scrapy','crawl','job58'])